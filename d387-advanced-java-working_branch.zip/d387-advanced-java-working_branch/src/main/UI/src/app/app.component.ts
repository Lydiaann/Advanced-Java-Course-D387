import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  // users: string[] = [];
  // priceUSD = 100;
  welcomeMessage: string = '';
  convertedTimes: string = '';
  rooms!: Room[];
  request!: ReserveRoomRequest;
  currentCheckInVal!: string;
  currentCheckOutVal!: string;
  submitted!: boolean;
  roomsearch!: FormGroup;

  private baseURL: string = 'http://localhost:8080';
  private getUrl: string = this.baseURL + '/room/reservation/v1/';
  private postUrl: string = this.baseURL + '/room/reservation/v1';

  constructor(private httpClient: HttpClient) {}

  ngOnInit() {
    this.roomsearch = new FormGroup({
      checkin: new FormControl(''),
      checkout: new FormControl('')
    });

    // Fetch welcome message on init
    this.getWelcomeMessage();
    this.getConvertedTimes();
    // Listen for form changes
    this.roomsearch.valueChanges.subscribe(x => {
      this.currentCheckInVal = x.checkin;
      this.currentCheckOutVal = x.checkout;
    });
  }

  getWelcomeMessage(): void {
    this.httpClient.get<{ en: string; fr: string }>('http://localhost:8080/api/welcome')
      .subscribe(
        (response) => {
          console.log("Received welcome messages:", response);
          this.welcomeMessage = `${response.en} | ${response.fr}`;
        },
        (error) => console.error('Error fetching welcome messages:', error)
      );
  }

  // onSubmit({ value, valid }: { value: Roomsearch; valid: boolean }) {
  //   this.getAll().subscribe(
  //     rooms => {
  //       console.log(Object.values(rooms)[0]);
  //       this.rooms = <Room[]>Object.values(rooms)[0];
  //     }
  //   );
  // }
  getConvertedTimes(): void {
    const apiUrl = `http://localhost:8080/api/presentation`;  // Your backend endpoint

    this.httpClient.get<string>(apiUrl).subscribe({
      next: (response) => {
        this.convertedTimes = response;  // Store the response in the convertedTimes variable
        console.log('Received times:', this.convertedTimes);  // Log for debugging
      },
      error: (err) => {
        console.error('Error fetching time conversion:', err);
        this.convertedTimes = 'Error fetching time conversion.';  // In case of error
      }
    });
  }

  onSubmit({ value, valid }: { value: Roomsearch; valid: boolean }) {
    if (valid) {
      this.getAll().subscribe(
        rooms => {

          const roomArray = Object.values(rooms)[0] as Room[];

          // Loop through each room and calculate the crude conversion
          this.rooms = roomArray.map(room => {
            // Parse the price from string to a float
            const price = parseFloat(room.price);

            // Calculate the crude conversions
            const priceUSD = price;  // Assuming the price is in USD already
            const priceCAD = price * 1.35;  // Crude conversion from USD to CAD
            const priceEUR = price * 0.85;  // Crude conversion from USD to EUR

            // Assign the converted prices back to the room object
            return {
              ...room,
              priceUSD: priceUSD.toFixed(2),  // Format to 2 decimal places
              priceCAD: priceCAD.toFixed(2),
              priceEUR: priceEUR.toFixed(2)
            };
          });

          // Log the rooms with converted prices
          console.log(this.rooms);
        },
        error => {
          // Handle any errors
          console.error('Error fetching rooms:', error);
        }
      );
    } else {
      console.log('Form is not valid');
    }
  }

  reserveRoom(value: string) {
    this.request = new ReserveRoomRequest(value, this.currentCheckInVal, this.currentCheckOutVal);
    this.createReservation(this.request);
  }

  createReservation(body: ReserveRoomRequest) {
    const options = {
      headers: new HttpHeaders().set('Content-Type', 'application/json')
    };

    this.httpClient.post(this.postUrl, body, options)
      .subscribe(res => console.log(res));
  }

  getAll(): Observable<any> {
    return this.httpClient.get(`${this.baseURL}/room/reservation/v1?checkin=${this.currentCheckInVal}&checkout=${this.currentCheckOutVal}`, { responseType: 'json' });
  }
}

export interface Roomsearch {
  checkin: string;
  checkout: string;
}

export interface Room {
  id: string;
  roomNumber: string;
  price: string;
  links: string;
  priceUSD?: string;  // Make them optional since they are computed
  priceCAD?: string;
  priceEUR?: string;
}

export class ReserveRoomRequest {
  constructor(
    public roomId: string,
    public checkin: string,
    public checkout: string
  ) {}
}
