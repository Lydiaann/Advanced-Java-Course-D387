package edu.wgu.d387_sample_code.Controller;

import java.util.Locale;
import java.util.ResourceBundle;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class WelcomeMessage {

    private static final String BUNDLE_NAME = "welcome";

    public static String getWelcomeMessage(Locale locale) {
        try {
            ResourceBundle bundle = ResourceBundle.getBundle(BUNDLE_NAME, locale);

            // Ensure message key exists to avoid runtime errors
            if (bundle.containsKey("welcomeMessage")) {
                return bundle.getString("welcomeMessage");
            } else {
                System.err.println("Missing 'welcomeMessage' key in " + locale);
                return "Welcome message not available.";
            }

        } catch (MissingResourceException e) {
            System.err.println("Resource bundle not found for locale: " + locale);
            return "Welcome message not found!";
        }
    }
}
