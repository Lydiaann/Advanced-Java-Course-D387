package edu.wgu.d387_sample_code.Controller;

import java.util.Locale;

public class DisplayMessage implements Runnable {
    private Locale locale;

    public DisplayMessage(Locale locale) {
        this.locale = locale;
    }

    @Override
    public void run() {
        System.out.println(WelcomeMessage.getWelcomeMessage(locale));
    }
}
