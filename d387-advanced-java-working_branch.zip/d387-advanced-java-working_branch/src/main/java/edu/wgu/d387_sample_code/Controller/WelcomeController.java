package edu.wgu.d387_sample_code.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:4200") // Allow CORS for the Angular frontend
@RequestMapping("/api")
public class WelcomeController {

    @GetMapping("/welcome")
    public Map<String, String> getWelcomeMessages() {
        Map<String, String> messages = new HashMap<>();
        messages.put("en", WelcomeMessage.getWelcomeMessage(Locale.ENGLISH)); // Fetch English message
        messages.put("fr", WelcomeMessage.getWelcomeMessage(Locale.CANADA_FRENCH)); // Fetch French message
        return messages;
    }
}
