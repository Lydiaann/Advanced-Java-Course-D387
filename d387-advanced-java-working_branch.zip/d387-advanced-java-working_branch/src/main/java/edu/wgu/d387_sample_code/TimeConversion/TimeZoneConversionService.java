package edu.wgu.d387_sample_code.TimeConversion;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;


@Service
public class TimeZoneConversionService {

    public String getTime() {

        // Define the time zones
        ZoneId zoneET = ZoneId.of("America/New_York");
        ZoneId zoneMT = ZoneId.of("America/Denver");
        ZoneId zoneUTC = ZoneId.of("UTC");

        // Get current time in each time zone
        ZonedDateTime timeET = ZonedDateTime.now(zoneET);
        ZonedDateTime timeMT = ZonedDateTime.now(zoneMT);
        ZonedDateTime timeUTC = ZonedDateTime.now(zoneUTC);

        // Define the time format
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm:ss a");

        // Format times for each time zone
        String timeInET = timeET.format(timeFormatter);
        String timeInMT = timeMT.format(timeFormatter);
        String timeInUTC = timeUTC.format(timeFormatter);

        // Concatenate the results into a single string
        String timeDisplay = timeInET + " ET | " + timeInMT + " MT | " + timeInUTC + " UTC";

        return timeDisplay;
    }
}
