package edu.wgu.d387_sample_code;

import edu.wgu.d387_sample_code.Controller.DisplayMessage;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.Locale;

@SpringBootApplication
public class D387SampleCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(D387SampleCodeApplication.class, args);

		// Display messages in console
		new Thread(new DisplayMessage(new Locale("en", "US"))).start();
		new Thread(new DisplayMessage(new Locale("fr", "CA"))).start();
	}
}
